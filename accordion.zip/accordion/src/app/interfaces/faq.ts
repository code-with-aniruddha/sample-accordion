export interface Faq {
  id: string;
  question: string;
  answer: string;
}
